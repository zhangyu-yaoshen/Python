#!/usr/bin/env python
# -*- coding:utf-8 -*-
# a = [1,2,3,4,5,6,7,8,9,10]
# a = [i+1 for i in a]
# print(a)

# a = [1,2,3,4,5,6,7,8,9,10]
# a = (i*i if i >5 else i for i in a)
# print(a)
# print(next(a))
# print(next(a))
# print(next(a))
# print(next(a))






