#!/usr/bin/env python
# -*- coding:utf-8 -*-
import os
print(globals())








